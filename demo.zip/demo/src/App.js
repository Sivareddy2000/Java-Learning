import './App.css';
import Movie from './components/Movie';
function App() {
  return (
    <div className="App">
      <Movie/>
    </div>
  );
}

export default App;
