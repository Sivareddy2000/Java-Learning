function FunctionalComponent(){
    
    return(<div>
        <img src=""></img>
    </div>)
}